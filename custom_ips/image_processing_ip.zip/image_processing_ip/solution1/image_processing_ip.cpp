#include <ap_int.h>
#include <hls_video.h>
#include "ap_axi_sdata.h"

#define IMAGE_HEIGHT 480
#define IMAGE_WIDTH  752
using namespace hls;

typedef stream<ap_axiu<24,1,1,1> > AXI_STREAM;
typedef stream<ap_axiu<8,1,1,1> > AXI_STREAM_Mono;
typedef stream<ap_axiu<32,1,1,1> > AXI_STREAM_Result;
typedef hls::Mat<IMAGE_HEIGHT, IMAGE_WIDTH, HLS_8UC3> RGB_IMAGE;
typedef hls::Mat<IMAGE_HEIGHT, IMAGE_WIDTH,HLS_8UC1>  GRAY_IMAGE;

struct IP_PRAMS
{
	ap_uint<32> userControl;
	ap_uint<32> CM_X_SUM;
	ap_uint<32> CM_Y_SUM;
	ap_uint<32> thresh;
	ap_uint<32> count;

};

//void image_processing_ip(AXI_STREAM& INPUT_STREAM, AXI_STREAM& OUTPUT_STREAM1,AXI_STREAM& OUTPUT_STREAM2,IP_PRAMS *params)
void image_processing_ip(AXI_STREAM& INPUT_STREAM, AXI_STREAM& OUTPUT_STREAM1)
{
	//#pragma HLS INTERFACE s_axilite port=params bundle=control
	//#pragma HLS INTERFACE s_axilite port=return bundle=control
	#pragma HLS INTERFACE axis register both port=OUTPUT_STREAM1
	#pragma HLS INTERFACE axis register both port=OUTPUT_STREAM2
	#pragma HLS INTERFACE axis register both port=INPUT_STREAM
	#pragma HLS DATAFLOW
	uint32_t X_sum=0,Y_sum=0;
	uint32_t cnt=0;
	//ap_uint<32> userControl=params->userControl;
	//uint32_t thr=params->thresh;

	ap_axiu<8,1,1,1> inputStream;
	ap_axiu<8,1,1,1> outPutStream;
	ap_axiu<8,1,1,1> ProcessStream;
	RGB_IMAGE src_image(IMAGE_HEIGHT, IMAGE_WIDTH);
	RGB_IMAGE tmp_image1(IMAGE_HEIGHT, IMAGE_WIDTH);
	RGB_IMAGE dst_image1(IMAGE_HEIGHT, IMAGE_WIDTH);
	RGB_IMAGE dst_image2(IMAGE_HEIGHT, IMAGE_WIDTH);

	RGB_IMAGE  img_0(IMAGE_HEIGHT, IMAGE_WIDTH);
	GRAY_IMAGE img_1(IMAGE_HEIGHT, IMAGE_WIDTH);
	GRAY_IMAGE  img_2(IMAGE_HEIGHT, IMAGE_WIDTH);
	GRAY_IMAGE  img_2a(IMAGE_HEIGHT, IMAGE_WIDTH);
	GRAY_IMAGE  img_2b(IMAGE_HEIGHT, IMAGE_WIDTH);
	GRAY_IMAGE  img_3(IMAGE_HEIGHT, IMAGE_WIDTH);
	GRAY_IMAGE  img_4(IMAGE_HEIGHT, IMAGE_WIDTH);
	GRAY_IMAGE  img_5(IMAGE_HEIGHT, IMAGE_WIDTH);
	RGB_IMAGE  img_6(IMAGE_HEIGHT, IMAGE_WIDTH);
	AXIvideo2Mat(INPUT_STREAM,img_0);
	hls::CvtColor<HLS_BGR2GRAY>(img_0, img_1);
	hls::GaussianBlur<3,3>(img_1,img_2);
	hls::Duplicate(img_2,img_2a,img_2b);
	hls::Sobel<1,0,3>(img_2a, img_3);
	hls::Sobel<0,1,3>(img_2b, img_4);
	hls::AddWeighted(img_4,0.5,img_3,0.5,0.0,img_5);
	hls::CvtColor<HLS_GRAY2RGB>(img_5, img_6);

	Mat2AXIvideo(img_6,OUTPUT_STREAM1);
}
